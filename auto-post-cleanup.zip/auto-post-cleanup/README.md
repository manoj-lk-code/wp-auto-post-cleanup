# wp-auto-post-cleanup

Deletes all posts and their associated images that are older than 90 days in your WordPress website.

# cronjob

Make sure your wordpress cronjob is working. 

# Days

You can change number of days in the file.

# Post batch

By default it delete 5 posts. you can change that as well.
